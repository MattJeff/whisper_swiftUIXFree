import SwiftUI
import AVFoundation

struct ContentView: View {
    
    
    @StateObject var whisperState = WhisperState()
    @State var transcribeChoice: Bool = false
    
    
    let recordings = ["aragorn", "Eric_Thomas", "J.F._Kennedy_-_Inaugural_address", "president","minutes"]
    let sampleSizes = ["ggml-large", "ggml-medium", "ggml-small.en", "ggml-tiny.en"]
    
    //MARK: - Body
    
    var body: some View {
        NavigationView {
            VStack(alignment: .leading) {
                
                Button("Transcribe", action: {
                    transcribeChoice.toggle()
                })
                .buttonStyle(.bordered)
                .disabled(!whisperState.canTranscribe)
                .padding(.bottom, 10)
                
             
                if transcribeChoice {
                    // Choix de l'enregistrement
                    Picker("Choose recording", selection: $whisperState.selectedRecording) {
                        ForEach(recordings, id: \.self) { recording in
                            Text(recording).tag(recording)
                        }
                    }
                    .pickerStyle(.menu)
                    .padding(.bottom, 10)

             
                    Picker("Choose sample size", selection: $whisperState.selectedSampleSize) {
                        ForEach(sampleSizes, id: \.self) { sampleSize in
                            Text(sampleSize).tag(sampleSize)
                        }
                    }
                    .pickerStyle(.menu)
                    .padding(.bottom, 10)
                }
                
               
                ScrollView {
                    Text(verbatim: whisperState.messageLog)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.bottom, 10)
                
                Spacer()
                
              
                if transcribeChoice {
                    Button("Go transcribe", action: {
                        Task {
                            await whisperState.transcribeSample()
                        }
                    })
                    .buttonStyle(.bordered)
                    .disabled(!whisperState.canTranscribe)
                }
                else {
                    Button(whisperState.isRecording ? "Stop recording" : "Start recording", action: {
                        Task {
                            await whisperState.toggleRecord()
                        }
                    })
                    .buttonStyle(.bordered)
                    .disabled(!whisperState.canTranscribe)
                }
            }
            .padding()
            .navigationTitle("Whisper SwiftUI Demo")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

